
export interface IUser {
    FNAME: String,
    LNAME: String,
    EMAIL: String,
    PWD : String
}