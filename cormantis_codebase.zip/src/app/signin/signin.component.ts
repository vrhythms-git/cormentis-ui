import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { CormentisService } from '../cormentis.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss']
})
export class SignInComponent implements OnInit {

  constructor(
    private formBuilder: FormBuilder,
    private router: Router, 
    private cormentisservice: CormentisService
    ) { }
  signInForm = new FormGroup({
    email: new FormControl(''),
    pwd: new FormControl(''),
  });

  ngOnInit(): void {
    this.signInForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      pwd: ['', Validators.required]
    })
  }

  signInWithGoogle() {
    alert('signInWithGoogle button pressed!')
  }


  signIn() {
    if (this.signInForm.invalid) {
      return
    }
    else {
      this.cormentisservice.userSignIn(this.signInForm.value).subscribe(data => {
        let resp = JSON.parse(JSON.stringify(data));
        console.log(`sign in service responded ith data : ${JSON.stringify(resp)}`);
        if (resp.status == 'success')
          this.router.navigate(['/main']);
        else if (resp.status == 'fail')
          alert(resp.errorMessage);

      })
    }
  }
}
